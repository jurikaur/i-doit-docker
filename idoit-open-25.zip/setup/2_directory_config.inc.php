<?php
/**
 * i-doit
 *
 * Installer
 * Step 1
 * System check
 *
 * @package    i-doit
 * @subpackage General
 * @copyright  synetics GmbH
 * @license    http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
?>
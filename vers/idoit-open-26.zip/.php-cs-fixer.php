<?php

return (new PhpCsFixer\Config())
    ->setRiskyAllowed(false)
    ->setRules([
        '@PSR2'        => true,
        'line_ending'  => false,
        'array_syntax' => ['syntax' => 'short'],
    ]);
